export default function About() {
  return (
    <section id="about" className="py-16 section">
      <div className="max-w-5xl mx-auto px-6 text-center">
        <h2 className="text-4xl font-bold mb-4">About <span className="text-blue-400">Me</span></h2>
        <div className="w-20 h-1 bg-blue-500 mx-auto mb-6"></div>
        <p className="text-slate-300 text-lg leading-relaxed">
          I'm Manish Barui, a Computer Application student from Jalpaiguri, West Bengal, India. I love building web applications, exploring new technologies, and learning every day. My interests include HTML, CSS, Python, and open-source. I believe in the power of creative collaboration and continuous improvement.
        </p>
      </div>
    </section>
  );
}
export default function Experience() {
  const experiences = [
    {
      title: "Web Development Projects",
      institution: "Personal & Academic",
      period: "2022 - Present",
      description: "Developed several websites using HTML, CSS, JavaScript, React, and Tailwind CSS. Learned best practices in responsive design and accessibility."
    },
    {
      title: "Python Programming",
      institution: "Academic",
      period: "2022 - Present",
      description: "Applied Python for scripting, automation, and data analysis in coursework and personal projects."
    }
  ];
  return (
    <section id="experience" className="py-16 section">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold mb-4">Experience</h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto"></div>
        </div>
        <div className="space-y-8">
          {experiences.map((exp, i) => (
            <div key={i} className="bg-slate-800 p-6 rounded-xl shadow">
              <h3 className="text-2xl font-bold mb-2 text-blue-400">{exp.title}</h3>
              <div className="flex justify-between text-slate-400 mb-2">
                <span>{exp.institution}</span>
                <span>{exp.period}</span>
              </div>
              <p className="text-slate-300">{exp.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
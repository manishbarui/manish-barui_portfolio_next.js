export default function Education() {
  const education = [
    {
      degree: "Bachelor of Computer Applications",
      institution: "University of North Bengal",
      period: "2022 - Present",
      description: "Studying core computer science concepts, programming, and web development."
    }
  ];
  return (
    <section id="education" className="py-16 bg-slate-900/30 section">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold mb-4">Education</h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto"></div>
        </div>
        <div className="space-y-8">
          {education.map((edu, i) => (
            <div key={i} className="bg-slate-800 p-6 rounded-xl shadow">
              <h3 className="text-2xl font-bold mb-2 text-blue-400">{edu.degree}</h3>
              <div className="flex justify-between text-slate-400 mb-2">
                <span>{edu.institution}</span>
                <span>{edu.period}</span>
              </div>
              <p className="text-slate-300">{edu.description}</p>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
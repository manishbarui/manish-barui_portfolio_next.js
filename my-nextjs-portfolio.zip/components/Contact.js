import { useState } from 'react';

const RATE_LIMIT = 30 * 60 * 1000;
const STORAGE_KEY = "lastSubmitTime";

export default function Contact() {
  const [status, setStatus] = useState({ text: '', type: '' });
  const [isLoading, setIsLoading] = useState(false);

  const showMessage = (text, type) => {
    setStatus({ text, type });
    setTimeout(() => setStatus({ text: '', type: '' }), 5000);
  };

  const handleSubmit = async (e) => {
    e.preventDefault(); 
    setIsLoading(true);
    setStatus({ text: '', type: '' });

    const contactForm = e.target;
    const currentTime = Date.now();
    const lastSubmitTime = parseInt(localStorage.getItem(STORAGE_KEY), 10);

    if (!isNaN(lastSubmitTime) && (currentTime - lastSubmitTime) < RATE_LIMIT) {
      showMessage('Please wait before sending another message.', 'error');
      setIsLoading(false);
      return;
    }
    const honeypot = contactForm.querySelector('input[name="_gotcha"]');
    if (honeypot.value) {
      setIsLoading(false);
      return;
    }
    try {
      const response = await fetch(contactForm.action, {
        method: 'POST',
        body: new FormData(contactForm),
        headers: {
          'Accept': 'application/json'
        }
      });
      if (response.ok) {
        showMessage('Thank you! Your message has been sent successfully.', 'success');
        contactForm.reset();
        localStorage.setItem(STORAGE_KEY, currentTime.toString()); 
      } else {
        const errorData = await response.json().catch(() => ({})); 
        throw new Error(errorData.error || 'Failed to send message');
      }
    } catch (error) {
      console.error('Form submission error:', error); 
      showMessage('Sorry, there was an error sending your message. Please try again.', 'error');
    } finally {
      setIsLoading(false);
    }
  };

  return (
    <section id="contact" className="py-10 bg-slate-800/30">
      <div className="max-w-7xl mx-auto px-6">
        <div className="text-center mb-10 section">
          <h2 className="text-4xl font-bold mb-4">Connect <span className="text-blue-400">With Me</span></h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto"></div>
        </div>
        <div className="grid md:grid-cols-2 gap-12 max-w-6xl mx-auto">
          <div className="section">
            <form id="contactForm" action="https://formspree.io/f/xrbqbyng" method="POST" className="space-y-6" onSubmit={handleSubmit}>
              <input type="text" name="_gotcha" className="honeypot" tabIndex="-1" autoComplete="off" /> 
              <div>
                <label htmlFor="name" className="block text-slate-300 mb-2">Your Name</label>
                <input type="text" id="name" name="name" placeholder="Your Name" required className="contact-input w-full px-4 py-3 rounded-lg focus:outline-none" />
              </div>
              <div>
                <label htmlFor="email" className="block text-slate-300 mb-2">Your Email</label>
                <input type="email" id="email" name="email" placeholder="Your Email" required className="contact-input w-full px-4 py-3 rounded-lg focus:outline-none" />
              </div>
              <div>
                <label htmlFor="message" className="block text-slate-300 mb-2">Your Message</label>
                <textarea id="message" name="message" rows="5" placeholder="Your Message" required className="contact-input w-full px-4 py-3 rounded-lg focus:outline-none"></textarea>
              </div>
              <button type="submit" id="submitBtn" className="btn-primary w-full py-3 rounded-lg font-medium" disabled={isLoading}>
                {isLoading ? (
                  <>
                    <span className="spinner"></span>Sending...
                  </>
                ) : (
                  <span>Send Message</span> 
                )}
              </button>
              {status.text && (
                <div 
                  id="formMessage" 
                  className={`form-message ${status.type} block`}
                  aria-label={`${status.type} message: ${status.text}`}
                >
                  {status.text}
                </div>
              )}
            </form>
          </div>
          <div className="section">
            <div className="text-center mb-10">
              <h3 className="text-2xl font-bold mb-6">Social Links</h3>
              <div className="flex justify-center space-x-8">
                <button className="social-icon text-4xl text-slate-300 hover:text-pink-500" onClick={() => window.open('https://www.instagram.com/manish_barui', '_blank')}>
                  <i className="fab fa-instagram"></i>
                </button>
                <button className="social-icon text-4xl text-slate-300 hover:text-blue-500" onClick={() => window.open('https://www.facebook.com/manish.barui01', '_blank')}>
                  <i className="fab fa-facebook"></i>
                </button>
                <button className="social-icon text-4xl text-slate-300 hover:text-blue-400" onClick={() => window.open('https://x.com/manish_barui', '_blank')}>
                  <i className="fab fa-twitter"></i>
                </button>
                <button className="social-icon text-4xl text-slate-300 hover:text-gray-400" onClick={() => window.open('https://github.com/manishbarui', '_blank')}>
                  <i className="fab fa-github"></i>
                </button>
              </div>
            </div>
            <div className="bg-slate-800 p-8 rounded-xl">
              <h3 className="text-2xl font-bold mb-6 text-center">Get In Touch</h3>
              <div className="space-y-4">
                <div className="flex items-center">
                  <div className="text-blue-400 text-xl mr-4">
                    <i className="fas fa-envelope"></i>
                  </div>
                  <div>
                    <p className="text-slate-300">Email me directly</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="text-blue-400 text-xl mr-4">
                    <i className="fas fa-map-marker-alt"></i>
                  </div>
                  <div>
                    <p className="text-slate-300">West Bengal, India</p>
                  </div>
                </div>
                <div className="flex items-center">
                  <div className="text-blue-400 text-xl mr-4">
                    <i className="fas fa-user-graduate"></i>
                  </div>
                  <div>
                    <p className="text-slate-300">Computer Application Student</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
      </div>
    </section>
  );
}
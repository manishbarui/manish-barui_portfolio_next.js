import { useState, useEffect, useRef } from 'react';
import Head from 'next/head';
import Nav from './Nav';
import Footer from './Footer';
import { gsap } from 'gsap';
import { ScrollTrigger } from 'gsap/dist/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

export default function Layout({ children }) {
  const [isDarkMode, setIsDarkMode] = useState(true);
  const progressBarRef = useRef(null);
  const backToTopRef = useRef(null);

  useEffect(() => {
    document.body.classList.toggle('light', !isDarkMode);
  }, [isDarkMode]);

  const toggleTheme = () => setIsDarkMode(prev => !prev);

  useEffect(() => {
    const handleScroll = () => {
      const scrollTop = window.pageYOffset || document.documentElement.scrollTop;
      const scrollHeight = document.documentElement.scrollHeight - document.documentElement.clientHeight;
      const scrollPercentage = (scrollTop / scrollHeight) * 100;

      if (progressBarRef.current) {
        progressBarRef.current.style.width = scrollPercentage + '%';
      }
      if (backToTopRef.current) {
        backToTopRef.current.classList.toggle('visible', window.pageYOffset > 300);
      }
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const scrollToTop = () => {
    window.scrollTo({ top: 0, behavior: 'smooth' });
  };

  useEffect(() => {
    gsap.utils.toArray('.section').forEach(section => {
      gsap.fromTo(section, 
        { opacity: 0, y: 30 },
        {
          opacity: 1,
          y: 0,
          duration: 0.8,
          scrollTrigger: {
            trigger: section,
            start: 'top 80%',
            toggleActions: 'play none none none'
          }
        }
      );
    });

    gsap.utils.toArray('.skill-card').forEach((card, i) => {
      gsap.fromTo(card, 
        { opacity: 0, y: 20 },
        {
          opacity: 1,
          y: 0,
          duration: 0.6,
          delay: i * 0.2,
          scrollTrigger: {
            trigger: card,
            start: 'top 90%',
            toggleActions: 'play none none none'
          }
        }
      );
    });
  }, []);

  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      window.scrollTo({
        top: section.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <>
      <Head>
        {/* Meta tags & SEO */}
        <meta name="description" content="Manish Barui - Computer Application Student & Web Developer from West Bengal, India." />
        <meta name="keywords" content="Manish Barui, Web Developer, Programming Python, HTML, CSS, JavaScript Computer Application, West Bengal, Portfolio, Technology Enthusiast" />
        <meta name="author" content="Manish Barui" />
        <meta name="robots" content="index, follow" />
        <meta name="google-site-verification" content="-x6zjJqdVJY8gScNJ6Yof0k6FtGTUCxcAstLFGFbwb4" />
        <meta property="og:type" content="website" />
        <meta property="og:url" content="https://manishbarui.staticrun.app/" />
        <meta property="og:title" content="Manish Barui - Computer Application Student & Web Developer" />
        <meta property="og:description" content="Passionate about technology, web development, and continuous learning. View my portfolio and connect with me." />
        <meta property="og:image" content="https://raw.githubusercontent.com/manishbarui/imagecontainer/refs/heads/main/Manish_Barui.jpg" />
        <link rel="canonical" href="https://manishbarui.staticrun.app/" />
        <link rel="preconnect" href="https://cdn.jsdelivr.net" />
        <link rel="preconnect" href="https://cdnjs.cloudflare.com" />
        <link rel="preconnect" href="https://fonts.googleapis.com" />
        <link rel="preconnect" href="https://fonts.gstatic.com" crossOrigin="true" />
        <link rel="icon" type="image/png" sizes="48x48" href="/favicon.png" />
        <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css" />
        <link href="https://fonts.googleapis.com/css2?family=Poppins:wght@300;400;500;600;700&display=swap" rel="stylesheet" />
        <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: `
          {
            "@context": "https://schema.org",
            "@type": "Person",
            "name": "Manish Barui",
            "url": "https://manishbarui.staticrun.app/",
            "image": "https://raw.githubusercontent.com/manishbarui/imagecontainer/refs/heads/main/Manish_Barui.jpg",
            "jobTitle": "Computer Application Student & Web Developer",
            "description": "Computer Application student and web developer based in Jalpaiguri, West Bengal, India.",
            "address": {
              "@type": "PostalAddress",
              "streetAddress": " Hakimpara", 
              "addressLocality": "Jalpaiguri",
              "addressRegion": "West Bengal", 
              "postalCode": "735101", 
              "addressCountry": "IN"
            },
            "sameAs": [
              "https://github.com/manishbarui",
              "https://x.com/manish_barui",
              "https://www.instagram.com/manish_barui", 
              "https://www.facebook.com/manish.barui01"
            ]
          } 
        ` }} />
      </Head>
      <div className="progress-bar" id="progressBar" ref={progressBarRef}></div>
      <Nav 
        isDarkMode={isDarkMode} 
        toggleTheme={toggleTheme} 
        scrollToSection={scrollToSection} 
      />
      <main>{children}</main>
      <Footer />
      <button 
        className="back-to-top" 
        id="backToTop" 
        ref={backToTopRef}
        onClick={scrollToTop}
        aria-label="Back to top"
      >
        <i className="fas fa-arrow-up"></i>
      </button>
    </>
  );
}
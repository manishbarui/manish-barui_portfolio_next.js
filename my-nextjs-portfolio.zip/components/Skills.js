export default function Skills() {
  const skills = [
    { name: "HTML", icon: "fab fa-html5", color: "text-orange-500" },
    { name: "CSS", icon: "fab fa-css3-alt", color: "text-blue-400" },
    { name: "JavaScript", icon: "fab fa-js-square", color: "text-yellow-400" },
    { name: "Python", icon: "fab fa-python", color: "text-blue-300" },
    { name: "React", icon: "fab fa-react", color: "text-cyan-400" },
    { name: "Tailwind CSS", icon: "fas fa-wind", color: "text-teal-400" },
    { name: "Git", icon: "fab fa-git-alt", color: "text-red-500" }
  ];
  return (
    <section id="skills" className="py-16 bg-slate-900/30 section">
      <div className="max-w-6xl mx-auto px-6">
        <div className="text-center mb-10">
          <h2 className="text-4xl font-bold mb-4">My <span className="text-blue-400">Skills</span></h2>
          <div className="w-20 h-1 bg-blue-500 mx-auto"></div>
        </div>
        <div className="grid grid-cols-2 md:grid-cols-4 lg:grid-cols-7 gap-8 justify-center">
          {skills.map(skill => (
            <div key={skill.name} className="skill-card bg-slate-800 p-6 rounded-xl flex flex-col items-center shadow">
              <i className={`${skill.icon} ${skill.color} text-4xl mb-3`} aria-hidden="true"></i>
              <span className="text-slate-200 font-medium">{skill.name}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}
import { useEffect } from 'react';
import { gsap } from 'gsap';

export default function Hero() {
  useEffect(() => {
    gsap.to('.hero-content', {
      opacity: 1,
      y: 0,
      duration: 1,
      ease: 'power3.out'
    });
  }, []);

  const scrollToSection = (sectionId) => {
    const section = document.getElementById(sectionId);
    if (section) {
      window.scrollTo({
        top: section.offsetTop - 80,
        behavior: 'smooth'
      });
    }
  };

  return (
    <section id="home" className="min-h-screen flex items-center pt-5">
      <div className="max-w-7xl mx-auto px-6 py-3 grid md:grid-cols-2 gap-8 items-center">
        <div className="hero-content">
          <h1 className="text-5xl md:text-7xl font-bold mb-4">Hi, I'm <span className="text-blue-400">Manish Barui</span></h1>
          <h2 className="text-2xl md:text-3xl text-slate-300 mb-6">Computer Application Student & Technology Enthusiast</h2>
          <p className="text-slate-400 mb-8 max-w-lg">Passionate about technology, science, and political discourse. Continuously expanding knowledge in web development and programming.</p>
          <div className="flex space-x-4">
            <button className="btn-primary px-8 py-3 rounded-full font-medium" onClick={() => scrollToSection('skills')}>View Skills</button>
            <button className="px-8 py-3 rounded-full font-medium border border-blue-400 text-blue-400 hover:bg-blue-400/10 transition" onClick={() => scrollToSection('contact')}>Contact Me</button>
          </div>
        </div>
        <div className="flex justify-center">
          <div className="relative">
            <div className="w-56 h-56 md:w-72 md:h-72 rounded-full overflow-hidden floating">
              <img src="https://raw.githubusercontent.com/manishbarui/imagecontainer/refs/heads/main/Manish_Barui_Profile.jpg" alt="Manish Barui" className="w-full h-full object-cover" loading="lazy" />
            </div>
            <div className="absolute -bottom-6 -right-6 w-32 h-32 bg-indigo-500/20 rounded-full"></div>
            <div className="absolute -top-6 -left-6 w-24 h-24 bg-blue-500/20 rounded-full"></div>
          </div>
        </div>
      </div>
    </section>
  );
}
import { useState } from 'react';

export default function Nav({ isDarkMode, toggleTheme, scrollToSection }) {
  const [isMenuOpen, setIsMenuOpen] = useState(false);

  const closeMobileMenu = () => setIsMenuOpen(false);
  const handleToggle = () => setIsMenuOpen(prev => !prev);

  const handleNavClick = (sectionId) => {
    scrollToSection(sectionId);
    closeMobileMenu();
  };

  return (
    <nav className="fixed w-full z-50 bg-slate-900/80 backdrop-blur-sm py-4 px-6">
      <div className="max-w-7xl mx-auto flex justify-between items-center">
        <div className="text-2xl font-bold text-blue-400">Manish<span className="text-white">.dev</span></div>
        <div className="hidden md:flex space-x-8">
          {['home', 'about', 'skills', 'experience', 'education', 'contact'].map(id => (
            <button key={id} className="nav-link text-slate-200" onClick={() => scrollToSection(id)} aria-label={`Maps to ${id} section`}>
              {id.charAt(0).toUpperCase() + id.slice(1)}
            </button>
          ))}
        </div>
        <div className="flex items-center space-x-4">
          <button 
            id="theme-toggle" 
            className={`text-slate-200 text-2xl transition-transform duration-300 ${!isDarkMode ? 'active' : ''}`} 
            onClick={toggleTheme} 
            aria-label={isDarkMode ? "Toggle light mode" : "Toggle dark mode"}
          >
            <i className={`fas ${isDarkMode ? 'fa-moon' : 'fa-sun'}`} aria-hidden="true"></i>
          </button>
          <button 
            id="hamburger" 
            className={`md:hidden text-slate-200 transition-transform duration-300 ${isMenuOpen ? 'active' : ''}`} 
            onClick={handleToggle} 
            aria-label="Open navigation menu"
          >
            <i className="fas fa-bars text-2xl" aria-hidden="true"></i>
          </button>
        </div>
      </div> 
      <div id="mobile-menu" className={`md:hidden ${isMenuOpen ? 'active' : ''}`}>
        {['home', 'about', 'skills', 'experience', 'education', 'contact'].map(id => (
          <button key={`mobile-${id}`} className="nav-link text-slate-200 text-left" onClick={() => handleNavClick(id)} aria-label={`Maps to ${id} section`}>
            {id.charAt(0).toUpperCase() + id.slice(1)}
          </button>
        ))}
      </div>
    </nav>
  );
}
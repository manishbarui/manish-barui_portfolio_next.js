export default function Footer() {
  return (
    <footer className="bg-slate-900 py-6 mt-12">
      <div className="max-w-7xl mx-auto px-6 flex flex-col md:flex-row justify-between items-center text-slate-400">
        <div>
          &copy; {new Date().getFullYear()} Manish Barui. All rights reserved.
        </div>
        <div className="flex space-x-4 mt-4 md:mt-0">
          <a href="https://github.com/manishbarui" target="_blank" rel="noopener noreferrer" aria-label="GitHub">
            <i className="fab fa-github text-xl hover:text-blue-400"></i>
          </a>
          <a href="https://x.com/manish_barui" target="_blank" rel="noopener noreferrer" aria-label="Twitter">
            <i className="fab fa-twitter text-xl hover:text-blue-400"></i>
          </a>
          <a href="https://www.instagram.com/manish_barui" target="_blank" rel="noopener noreferrer" aria-label="Instagram">
            <i className="fab fa-instagram text-xl hover:text-pink-500"></i>
          </a>
          <a href="https://www.facebook.com/manish.barui01" target="_blank" rel="noopener noreferrer" aria-label="Facebook">
            <i className="fab fa-facebook text-xl hover:text-blue-500"></i>
          </a>
        </div>
      </div>
    </footer>
  );
}
import Head from 'next/head';
import Layout from '../components/Layout';
import Hero from '../components/Hero';
import About from '../components/About';
import Skills from '../components/Skills';
import Experience from '../components/Experience';
import Education from '../components/Education';
import Contact from '../components/Contact';

export default function Home() {
  return (
    <>
      <Head>
        <title>Manish Barui - Computer Application Student & Web Developer | Portfolio</title>
      </Head>
      <Layout>
        <Hero />
        <About />
        <Skills />
        <Experience />
        <Education />
        <Contact />
      </Layout>
    </>
  );
}